package com.example.chilldrenofpatria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class C2_Ad1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c2__ad1);


    }
}
