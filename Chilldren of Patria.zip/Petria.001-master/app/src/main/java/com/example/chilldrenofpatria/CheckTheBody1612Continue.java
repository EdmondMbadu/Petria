package com.example.chilldrenofpatria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


//Obsolete. This class was created by mistake. It is no used so far
public class CheckTheBody1612Continue extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_the_body1612_continue);
    }
}
